import { 
  Shield, 
  Code, 
  TrendingUp, 
  Gamepad2, 
  Search, 
  Globe, 
  Cpu, 
  Lock,
  Mail,
  Instagram,
  MessageCircle
} from 'lucide-react';
import { SkillCategory, Service, Project, SocialLink, NavItem } from './types';

// Personal Info
export const PERSONAL_INFO = {
  name: "Abdur Rahman Mahmood",
  nickname: "Tawsif",
  location: "Bangladesh",
  tagline: "Securing systems, building solutions, and trading the future of finance.",
  profileImage: "https://tawsif0950.github.io/20241224_162946.jpg",
  roles: [
    "Cybersecurity Expert",
    "Ethical Hacker",
    "Forex & Crypto Trader",
    "Blockchain Enthusiast",
    "Web Developer",
    "Free Fire Esports Player"
  ]
};

// About Text
export const ABOUT_TEXT = {
  p1: "Hi, I'm Abdur Rahman from Bangladesh — a Cybersecurity Expert, Ethical Hacker, Web Developer, Blockchain Enthusiast, and Crypto Trader.",
  p2: "I specialize in securing digital systems, solving CTF challenges, and exploring the dark web to identify cyber threats. My passion lies in protecting digital infrastructures and staying ahead of emerging security vulnerabilities.",
  p3: "Beyond cybersecurity, I build innovative web and blockchain solutions and actively trade cryptocurrencies, analyzing market trends and making strategic decisions in the volatile crypto space.",
  p4: "I'm also a competitive Free Fire esports player, combining strategy and skill both online and in gaming arenas. This unique blend of technical expertise and competitive gaming gives me a distinctive edge.",
  cta: "I'm always open to collaboration, security audits, or consulting opportunities. Let's connect and create something extraordinary!"
};

// Navigation
export const NAV_ITEMS: NavItem[] = [
  { label: "Home", to: "home" },
  { label: "About", to: "about" },
  { label: "Skills", to: "skills" },
  { label: "Services", to: "services" },
  { label: "Projects", to: "projects" },
  { label: "Trading", to: "trading" },
  { label: "Esports", to: "esports" },
  { label: "Contact", to: "contact" },
];

// Skills
export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: "Cybersecurity & Hacking",
    icon: Shield,
    skills: ["Network Security", "Web App Security", "CTF Challenges", "Dark Web Monitoring", "OSINT", "Penetration Testing"]
  },
  {
    title: "Development",
    icon: Code,
    skills: ["HTML5", "CSS3", "JavaScript", "React.js", "Web Development", "Backend APIs"]
  },
  {
    title: "Trading & Blockchain",
    icon: TrendingUp,
    skills: ["Forex Trading", "Crypto Trading", "Technical Analysis", "Risk Management", "Blockchain Fundamentals"]
  },
  {
    title: "Esports & Strategy",
    icon: Gamepad2,
    skills: ["Free Fire Competitive", "Team Leadership", "Strategic Planning", "Tournament Experience"]
  }
];

// Services
export const SERVICES: Service[] = [
  {
    title: "Penetration Testing",
    description: "Comprehensive security audits to identify vulnerabilities in your network and applications before malicious actors do.",
    icon: Shield
  },
  {
    title: "Web Security Review",
    description: "Detailed analysis of your web applications to ensure they meet modern security standards and protect user data.",
    icon: Lock
  },
  {
    title: "Web Development",
    description: "Building responsive, modern, and secure portfolio websites and web applications tailored to your specific needs.",
    icon: Globe
  },
  {
    title: "Crypto Consulting",
    description: "Basic guidance on cryptocurrency fundamentals, wallet security, and understanding blockchain technology trends.",
    icon: Cpu
  }
];

// Projects
export const PROJECTS: Project[] = [
  {
    title: "CTF & Labs Dashboard",
    description: "A centralized platform for tracking Capture The Flag progress and managing cybersecurity lab environments.",
    tags: ["React", "Node.js", "Security"]
  },
  {
    title: "Web Security Scanner",
    description: "Conceptual tool designed to perform automated vulnerability scans on web applications for common threats.",
    tags: ["Python", "Automation", "InfoSec"]
  },
  {
    title: "Crypto Portfolio Tracker",
    description: "A real-time dashboard for tracking crypto assets, analyzing profit/loss, and monitoring market movements.",
    tags: ["API Integration", "Finance", "Analytics"]
  },
  {
    title: "Personal Portfolio",
    description: "This high-performance, responsive portfolio website built with modern React and Tailwind CSS.",
    tags: ["React", "TypeScript", "Tailwind"]
  }
];

// Social Links
export const SOCIAL_LINKS: SocialLink[] = [
  {
    platform: "Email",
    url: "mailto:tawsif0950@gmail.com",
    icon: Mail,
    label: "Email Me"
  },
  {
    platform: "WhatsApp",
    url: "https://wa.me/+8801631417328",
    icon: MessageCircle, // Using MessageCircle as a proxy for generic chat/WhatsApp if specific icon unavailable
    label: "Chat on WhatsApp"
  },
  {
    platform: "TryHackMe",
    url: "https://tryhackme.com/p/tawsif0950",
    icon: Shield,
    label: "TryHackMe"
  },
  {
    platform: "Discord",
    url: "https://discord.com/users/tawsif095",
    icon: Gamepad2,
    label: "Discord"
  },
  {
    platform: "Instagram",
    url: "https://instagram.com/legendarytawsif",
    icon: Instagram,
    label: "Instagram"
  }
];