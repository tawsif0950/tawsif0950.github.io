import React from 'react';
import { motion } from 'framer-motion';
import { ABOUT_TEXT, PERSONAL_INFO } from '../constants';
import { MapPin, User, Code, Cpu, ShieldCheck } from 'lucide-react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">Behind the Screen</h2>
          <p className="text-gray-400 max-w-2xl text-lg">
            A glimpse into who I am, what I do, and the drive behind my work.
          </p>
        </div>

        <div className="grid md:grid-cols-12 gap-6">
          
          {/* Main Bio Card - Large */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-8 bg-brand-card/50 backdrop-blur-sm rounded-3xl p-8 border border-white/5 hover:border-white/10 transition-colors"
          >
            <div className="h-full flex flex-col justify-between gap-6">
              <div className="space-y-4 text-gray-300 leading-relaxed text-lg">
                <p><span className="text-white font-semibold">Hello!</span> {ABOUT_TEXT.p1}</p>
                <p>{ABOUT_TEXT.p2}</p>
                <p>{ABOUT_TEXT.p3}</p>
              </div>
              <div className="flex flex-wrap gap-3 pt-4">
                 <span className="px-4 py-2 rounded-full bg-brand-primary/10 text-brand-primary text-sm font-medium border border-brand-primary/20">Security</span>
                 <span className="px-4 py-2 rounded-full bg-brand-secondary/10 text-brand-secondary text-sm font-medium border border-brand-secondary/20">Development</span>
                 <span className="px-4 py-2 rounded-full bg-brand-accent/10 text-brand-accent text-sm font-medium border border-brand-accent/20">Trading</span>
              </div>
            </div>
          </motion.div>

          {/* Stats/Location Card - Side */}
          <div className="md:col-span-4 grid grid-rows-2 gap-6">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className="bg-gradient-to-br from-brand-card to-brand-dark rounded-3xl p-6 border border-white/5 flex items-center justify-between group hover:border-brand-secondary/30 transition-all"
            >
              <div>
                <p className="text-gray-400 text-sm font-mono mb-1">Location</p>
                <h3 className="text-2xl font-bold text-white">{PERSONAL_INFO.location}</h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-brand-secondary/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <MapPin className="text-brand-secondary" size={24} />
              </div>
            </motion.div>

            <motion.div 
               initial={{ opacity: 0, x: 20 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
               transition={{ delay: 0.2 }}
               className="bg-gradient-to-br from-brand-card to-brand-dark rounded-3xl p-6 border border-white/5 flex items-center justify-between group hover:border-brand-accent/30 transition-all"
            >
              <div>
                <p className="text-gray-400 text-sm font-mono mb-1">Experience</p>
                <h3 className="text-xl font-bold text-white">Multi-Disciplinary</h3>
              </div>
              <div className="w-12 h-12 rounded-full bg-brand-accent/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                <ShieldCheck className="text-brand-accent" size={24} />
              </div>
            </motion.div>
          </div>

          {/* Bottom Wide Card - Gaming/Extra */}
          <motion.div 
             initial={{ opacity: 0, y: 20 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ delay: 0.3 }}
             className="md:col-span-12 bg-white/5 rounded-3xl p-8 border border-white/5 flex flex-col md:flex-row items-center gap-8"
          >
            <div className="flex-1">
               <h3 className="text-xl font-bold text-white mb-2">Beyond the Code</h3>
               <p className="text-gray-400">{ABOUT_TEXT.p4}</p>
            </div>
            <div className="flex gap-4">
                <div className="text-center px-6 py-3 rounded-2xl bg-black/20 border border-white/5">
                    <span className="block text-2xl font-bold text-white">CTF</span>
                    <span className="text-xs text-gray-500">Player</span>
                </div>
                 <div className="text-center px-6 py-3 rounded-2xl bg-black/20 border border-white/5">
                    <span className="block text-2xl font-bold text-white">Top</span>
                    <span className="text-xs text-gray-500">Fragger</span>
                </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default About;