import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Terminal } from 'lucide-react';
import { NAV_ITEMS } from '../constants';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 flex justify-center pt-6 px-4 transition-all duration-300 pointer-events-none`}
      >
        <div className={`
          pointer-events-auto
          backdrop-blur-xl bg-brand-card/80 border border-white/10 
          rounded-full px-6 py-3 flex items-center justify-between gap-8
          shadow-[0_0_20px_rgba(0,0,0,0.5)]
          transition-all duration-300
          ${isScrolled ? 'w-[90%] max-w-5xl' : 'w-full max-w-7xl bg-transparent border-transparent shadow-none backdrop-blur-none'}
        `}>
          {/* Logo */}
          <a href="#home" className="flex items-center gap-2 group">
            <div className="p-2 rounded-lg bg-brand-secondary/10 group-hover:bg-brand-secondary/20 transition-colors">
              <Terminal size={20} className="text-brand-secondary" />
            </div>
            <span className="font-mono font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
              Tawsif
            </span>
          </a>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.label}
                href={`#${item.to}`}
                className="relative px-4 py-2 text-sm font-medium text-gray-400 hover:text-white transition-colors rounded-full hover:bg-white/5 group"
              >
                {item.label}
                <span className="absolute inset-x-4 bottom-2 h-px bg-brand-secondary scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300" />
              </a>
            ))}
          </div>

          {/* Hire Me Button (Desktop) */}
          <div className="hidden md:block">
            <a 
              href="#contact"
              className="px-5 py-2 rounded-full bg-white text-black font-semibold text-sm hover:bg-brand-secondary hover:text-white transition-colors duration-300"
            >
              Lets Talk
            </a>
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden p-2 text-gray-300 hover:text-white"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-brand-dark/95 backdrop-blur-xl pt-24 px-6 md:hidden"
          >
            <div className="flex flex-col space-y-4">
              {NAV_ITEMS.map((item, idx) => (
                <motion.a
                  key={item.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.05 }}
                  href={`#${item.to}`}
                  onClick={() => setIsOpen(false)}
                  className="text-2xl font-bold text-gray-300 hover:text-brand-secondary"
                >
                  {item.label}
                </motion.a>
              ))}
              <div className="h-px bg-white/10 my-6" />
              <a 
                href="#contact"
                onClick={() => setIsOpen(false)}
                className="w-full py-4 rounded-xl bg-brand-primary text-white font-bold text-center"
              >
                Start a Project
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;