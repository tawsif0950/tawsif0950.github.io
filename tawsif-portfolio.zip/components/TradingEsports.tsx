import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Crosshair, Activity, BarChart2, Trophy } from 'lucide-react';

const TradingEsports: React.FC = () => {
  return (
    <div className="bg-brand-dark overflow-hidden">
      
      {/* Trading Section */}
      <section id="trading" className="py-24 border-t border-white/5 relative">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-green-500/5 rounded-full blur-[100px] pointer-events-none" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
               initial={{ opacity: 0, x: -30 }}
               whileInView={{ opacity: 1, x: 0 }}
               viewport={{ once: true }}
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-900/20 text-green-400 text-sm font-mono mb-6 border border-green-500/20">
                <TrendingUp size={16} /> Market Analysis
              </div>
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Disciplined <span className="text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-teal-500">Trading</span> Strategies
              </h2>
              <p className="text-gray-400 text-lg mb-8 leading-relaxed">
                I navigate the volatile waves of Forex and Crypto with a calculated, analytical approach. Focusing on price action and risk management, I treat trading not as gambling, but as a game of probabilities and psychology.
              </p>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <Activity className="text-green-400 mb-2" size={24} />
                  <h4 className="text-white font-bold">Technical Analysis</h4>
                  <p className="text-sm text-gray-500">Chart patterns & indicators</p>
                </div>
                <div className="p-4 rounded-xl bg-white/5 border border-white/5">
                  <BarChart2 className="text-green-400 mb-2" size={24} />
                  <h4 className="text-white font-bold">Risk Control</h4>
                  <p className="text-sm text-gray-500">Strict SL/TP management</p>
                </div>
              </div>
            </motion.div>
            
            <motion.div
               initial={{ opacity: 0, scale: 0.9 }}
               whileInView={{ opacity: 1, scale: 1 }}
               viewport={{ once: true }}
               className="relative h-[400px] bg-brand-card rounded-3xl border border-white/5 p-8 flex flex-col justify-between overflow-hidden group"
            >
              <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] opacity-50"></div>
              
              <div className="relative z-10">
                <div className="flex justify-between items-center mb-8">
                  <span className="text-gray-400 font-mono">BTC/USD</span>
                  <span className="text-green-400 font-mono">+12.4%</span>
                </div>
                {/* Abstract Chart Line */}
                <svg className="w-full h-48 stroke-green-500 stroke-2 fill-none drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]" viewBox="0 0 100 50" preserveAspectRatio="none">
                  <path d="M0 40 Q 10 45, 20 30 T 40 35 T 60 20 T 80 25 T 100 5" vectorEffect="non-scaling-stroke" />
                </svg>
              </div>
              
              <div className="relative z-10 mt-auto">
                 <div className="flex gap-3">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                    <span className="w-3 h-3 rounded-full bg-green-500"></span>
                 </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Esports Section */}
      <section id="esports" className="py-24 relative bg-gradient-to-b from-brand-dark to-[#0a051e]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
           <div className="relative rounded-[3rem] overflow-hidden border border-purple-500/20 bg-brand-card/50 p-8 md:p-16">
             {/* Background Decoration */}
             <div className="absolute -right-20 -top-20 w-96 h-96 bg-purple-600/20 blur-[100px] rounded-full pointer-events-none"></div>

             <div className="relative z-10 flex flex-col md:flex-row items-center gap-12">
                <div className="flex-1 text-center md:text-left">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-purple-900/20 text-purple-400 text-sm font-mono mb-6 border border-purple-500/20">
                    <Crosshair size={16} /> Competitive Esports
                  </div>
                  <h2 className="text-4xl font-bold text-white mb-6">Free Fire <span className="text-purple-500">Elite</span></h2>
                  <p className="text-gray-300 mb-8 text-lg">
                    My competitive spirit translates from the terminal to the battleground. As an esports athlete, I hone rapid decision-making, team communication, and strategic execution under pressure.
                  </p>
                  
                  <div className="flex flex-wrap gap-4 justify-center md:justify-start">
                    <div className="px-6 py-3 bg-white/5 rounded-xl border border-white/10 flex items-center gap-3">
                        <Trophy className="text-yellow-400" size={20} />
                        <span className="text-white font-bold">Tournament Exp</span>
                    </div>
                    <div className="px-6 py-3 bg-white/5 rounded-xl border border-white/10 flex items-center gap-3">
                        <Crosshair className="text-purple-400" size={20} />
                        <span className="text-white font-bold">High K/D Ratio</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex-1 flex justify-center">
                  {/* Decorative Badge */}
                  <div className="relative w-64 h-64">
                    <div className="absolute inset-0 border-4 border-purple-500/30 rounded-full animate-spin-slow dashed"></div>
                    <div className="absolute inset-4 border-2 border-white/10 rounded-full"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                        <Crosshair size={80} className="text-white drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]" />
                    </div>
                  </div>
                </div>
             </div>
           </div>
        </div>
      </section>
    </div>
  );
};

export default TradingEsports;