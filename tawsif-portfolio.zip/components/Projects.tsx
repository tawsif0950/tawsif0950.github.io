import React from 'react';
import { motion } from 'framer-motion';
import { PROJECTS } from '../constants';
import { ArrowUpRight, FolderGit2 } from 'lucide-react';

const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-24 bg-black/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">Selected Works</h2>
          <p className="text-gray-400 max-w-2xl">
            A collection of concepts, security tools, and applications I've worked on.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {PROJECTS.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative bg-brand-card rounded-3xl overflow-hidden border border-white/5 hover:border-white/10 transition-all"
            >
              <div className="p-8 h-full flex flex-col">
                <div className="flex justify-between items-start mb-6">
                  <div className="p-3 rounded-full bg-white/5 text-white group-hover:bg-white group-hover:text-black transition-colors duration-300">
                    <FolderGit2 size={24} />
                  </div>
                  <div className="px-3 py-1 rounded-full bg-white/5 text-xs font-mono text-gray-400 border border-white/5">
                    2024
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-white mb-3 group-hover:text-brand-primary transition-colors">
                  {project.title}
                </h3>
                
                <p className="text-gray-400 mb-8 leading-relaxed">
                  {project.description}
                </p>

                <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between">
                   <div className="flex gap-2">
                      {project.tags.map(tag => (
                        <span key={tag} className="text-xs font-medium text-gray-500 px-2 py-1 rounded bg-black/20">
                          #{tag}
                        </span>
                      ))}
                   </div>
                   <button className="text-white hover:text-brand-primary transition-colors">
                      <ArrowUpRight size={20} />
                   </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default Projects;