import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Terminal, Shield, Cpu } from 'lucide-react';
import { PERSONAL_INFO } from '../constants';

const Hero: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20 md:pt-0">
      
      {/* Dynamic Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-[20%] left-[10%] w-[500px] h-[500px] bg-brand-primary/10 rounded-full blur-[120px] animate-pulse-slow" />
        <div className="absolute bottom-[20%] right-[10%] w-[500px] h-[500px] bg-brand-accent/10 rounded-full blur-[120px] animate-pulse-slow" style={{ animationDelay: '4s' }} />
        <div className="absolute inset-0 bg-cyber-grid bg-[size:40px_40px] opacity-20"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 items-center">
          
          {/* Text Content */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="lg:col-span-7 order-2 lg:order-1 text-center lg:text-left"
          >
            {/* Status Indicator */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-8 hover:bg-white/10 transition-colors cursor-default"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
              </span>
              <span className="text-sm font-mono text-gray-300">System Online & Ready</span>
            </motion.div>

            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 tracking-tight leading-[0.95]">
              <span className="block text-gray-500 text-3xl md:text-4xl mb-2 font-medium">I am</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-gray-200 to-gray-500">
                {PERSONAL_INFO.nickname}
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-400 mb-10 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-light">
              {PERSONAL_INFO.tagline}
            </p>

            {/* Tech Stack Pills */}
            <div className="flex flex-wrap gap-3 justify-center lg:justify-start mb-12">
              {PERSONAL_INFO.roles.slice(0, 4).map((role, i) => (
                <motion.span 
                  key={i}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 + (i * 0.1) }}
                  className="px-4 py-2 text-sm font-mono text-gray-300 bg-brand-card border border-white/5 rounded-lg hover:border-brand-secondary/30 transition-colors"
                >
                  {role}
                </motion.span>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-5 justify-center lg:justify-start">
              <a 
                href="#projects"
                className="group relative px-8 py-4 rounded-xl bg-white text-black font-bold overflow-hidden transition-all hover:scale-105 hover:shadow-[0_0_40px_-10px_rgba(255,255,255,0.3)]"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Explore Work <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
                </span>
              </a>
              
              <a 
                href="#contact"
                className="px-8 py-4 rounded-xl border border-white/10 bg-white/5 text-white font-medium hover:bg-white/10 hover:border-white/20 transition-all flex items-center gap-2 justify-center backdrop-blur-md"
              >
                Let's Collaborate
              </a>
            </div>
          </motion.div>

          {/* Profile Image / Graphic */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-5 order-1 lg:order-2 flex justify-center relative"
          >
            <div className="relative w-[280px] h-[280px] md:w-[400px] md:h-[400px]">
              
              {/* Spinning Rings */}
              <div className="absolute inset-[-20px] border border-white/5 rounded-full animate-[spin_10s_linear_infinite]"></div>
              <div className="absolute inset-[-40px] border border-brand-secondary/20 rounded-full animate-[spin_15s_linear_infinite_reverse] opacity-50"></div>
              
              {/* Floating Icons */}
              <motion.div 
                animate={{ y: [0, -15, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="absolute -top-8 -right-8 p-4 bg-brand-card border border-white/10 rounded-2xl shadow-xl z-20 backdrop-blur-md"
              >
                <Shield className="text-brand-secondary" size={32} />
              </motion.div>

              <motion.div 
                animate={{ y: [0, 15, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                className="absolute -bottom-8 -left-8 p-4 bg-brand-card border border-white/10 rounded-2xl shadow-xl z-20 backdrop-blur-md"
              >
                <Terminal className="text-brand-accent" size={32} />
              </motion.div>

              {/* Main Image Container */}
              <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-white/5 bg-brand-card shadow-2xl z-10 group">
                <div className="absolute inset-0 bg-gradient-to-tr from-brand-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-20"></div>
                <img 
                  src={PERSONAL_INFO.profileImage} 
                  alt={PERSONAL_INFO.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 grayscale-[20%] group-hover:grayscale-0"
                />
              </div>

            </div>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        >
          <div className="w-[1px] h-16 bg-gradient-to-b from-transparent via-brand-secondary to-transparent opacity-50"></div>
        </motion.div>

      </div>
    </section>
  );
};

export default Hero;