import React from 'react';
import { PERSONAL_INFO } from '../constants';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black border-t border-white/5 py-8 relative z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          
          <div className="text-center md:text-left">
            <p className="text-gray-500 text-xs tracking-wider uppercase">
              &copy; {currentYear} {PERSONAL_INFO.name}
            </p>
          </div>

          <div className="flex items-center gap-6">
             <span className="text-gray-600 text-xs font-mono tracking-tight">Designed & Developed by Abdur Rahman</span>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;