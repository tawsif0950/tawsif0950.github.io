import React from 'react';
import { motion } from 'framer-motion';
import { SERVICES } from '../constants';
import { ArrowUpRight } from 'lucide-react';

const Services: React.FC = () => {
  return (
    <section id="services" className="py-32 relative">
      {/* Subtle Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-brand-dark to-[#05080f]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="mb-20">
           <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">Services</h2>
           <div className="h-1 w-20 bg-brand-secondary rounded-full"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {SERVICES.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group relative p-8 rounded-3xl bg-white/[0.02] border border-white/5 hover:bg-white/[0.05] hover:border-white/10 transition-all duration-500 flex flex-col justify-between h-full overflow-hidden"
            >
              {/* Hover Glow */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-brand-primary/20 blur-[60px] rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 translate-x-10 -translate-y-10" />

              <div className="relative z-10">
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-white mb-8 group-hover:scale-110 transition-transform duration-500 border border-white/5">
                  <service.icon size={28} className="group-hover:text-brand-secondary transition-colors" />
                </div>
                
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-brand-secondary transition-colors">{service.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-8 opacity-80 group-hover:opacity-100 transition-opacity">
                  {service.description}
                </p>
              </div>

              <div className="relative z-10 pt-6 border-t border-white/5 flex items-center justify-between">
                 <span className="text-xs font-mono text-gray-500 uppercase tracking-widest group-hover:text-white transition-colors">Learn More</span>
                 <ArrowUpRight size={16} className="text-gray-500 group-hover:text-brand-secondary group-hover:-translate-y-1 group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;