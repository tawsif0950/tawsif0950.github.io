import React from 'react';
import { motion } from 'framer-motion';
import { SOCIAL_LINKS } from '../constants';
import { ArrowUpRight, Mail } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-32 relative overflow-hidden">
      
      {/* Background Elements */}
      <div className="absolute inset-0 bg-brand-dark">
         <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[500px] bg-gradient-to-b from-brand-primary/5 to-transparent pointer-events-none" />
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-7xl font-bold text-white mb-8 tracking-tight">
            Let's <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-secondary to-brand-accent">Work Together</span>
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto font-light">
            I am currently available for freelance projects, security consultations, and collaborative opportunities.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-6">
            {/* Main Email Card */}
            <motion.a
              href="mailto:tawsif0950@gmail.com"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="md:col-span-2 group relative p-10 rounded-3xl bg-gradient-to-br from-white/10 to-white/5 border border-white/10 overflow-hidden hover:border-brand-primary/50 transition-all duration-500"
            >
               <div className="absolute inset-0 bg-brand-primary/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
               <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6 text-center md:text-left">
                  <div className="flex items-center gap-6">
                     <div className="p-4 rounded-2xl bg-white/10 text-white group-hover:scale-110 transition-transform duration-500">
                        <Mail size={32} />
                     </div>
                     <div>
                        <h3 className="text-2xl font-bold text-white mb-1">Send an Email</h3>
                        <p className="text-gray-400 text-lg">tawsif0950@gmail.com</p>
                     </div>
                  </div>
                  <div className="px-6 py-3 rounded-full bg-white text-black font-bold flex items-center gap-2 group-hover:bg-brand-primary group-hover:text-white transition-colors">
                     Write Message <ArrowUpRight size={18} />
                  </div>
               </div>
            </motion.a>

            {/* Social Grid */}
            {SOCIAL_LINKS.filter(l => l.platform !== 'Email').map((link, idx) => (
               <motion.a
                  key={link.platform}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="group p-8 rounded-3xl bg-brand-card border border-white/5 hover:border-brand-secondary/30 transition-all duration-300 flex items-center justify-between hover:-translate-y-1"
               >
                  <div className="flex items-center gap-4">
                     <div className="text-gray-400 group-hover:text-white transition-colors">
                        <link.icon size={24} />
                     </div>
                     <span className="text-xl font-bold text-gray-300 group-hover:text-white transition-colors">{link.label}</span>
                  </div>
                  <ArrowUpRight className="text-gray-600 group-hover:text-brand-secondary group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
               </motion.a>
            ))}
        </div>

      </div>
    </section>
  );
};

export default Contact;